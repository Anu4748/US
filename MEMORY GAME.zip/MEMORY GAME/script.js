// Cards array with image paths (adjusted for your folder and file names)
const cards = [
    { id: 1, img: "./Images/image1.jpg" },
    { id: 2, img: "./Images/image2.jpg" },
    { id: 3, img: "./Images/image3.jpg" },
    { id: 4, img: "./Images/image4.jpg" },
    { id: 5, img: "./Images/image5.jpg" },
    { id: 6, img: "./Images/image6.jpg" },
    { id: 7, img: "./Images/image7.jpg" },
    { id: 8, img: "./Images/image8.jpg" },
    { id: 9, img: "./Images/image9.jpg" },
    { id: 10, img: "./Images/image10.jpg" },
  ];
  
  // Duplicate cards and shuffle them
  let gameCards = [...cards, ...cards].sort(() => Math.random() - 0.5);
  
  const gameBoard = document.getElementById("game-board");
  const message = document.getElementById("message");
  
  let firstCard = null;
  let secondCard = null;
  let matchedPairs = 0;
  
  // Create and display the cards
  function createCards() {
    gameCards.forEach((card, index) => {
      const cardElement = document.createElement("div");
      cardElement.classList.add("card");
      cardElement.dataset.id = card.id;
      cardElement.dataset.index = index;
      cardElement.style.backgroundImage = "url('./Images/card.png')"; // Back card image
      cardElement.addEventListener("click", flipCard);
      gameBoard.appendChild(cardElement);
    });
  }
  
  // Flip card logic
  function flipCard(event) {
    const clickedCard = event.target;
    const cardIndex = clickedCard.dataset.index;
  
    if (clickedCard.classList.contains("flipped") || (firstCard && secondCard)) return;
  
    clickedCard.style.backgroundImage = `url(${gameCards[cardIndex].img})`;
    clickedCard.classList.add("flipped");
  
    if (!firstCard) {
      firstCard = clickedCard;
    } else {
      secondCard = clickedCard;
  
      if (firstCard.dataset.id === secondCard.dataset.id) {
        matchedPairs++;
        firstCard = null;
        secondCard = null;
  
        if (matchedPairs === cards.length) {
          setTimeout(() => {
            gameBoard.classList.add("hidden");
            message.classList.remove("hidden");
          }, 500);
        }
      } else {
        setTimeout(() => {
          firstCard.style.backgroundImage = "url('./Images/card.png')";
          secondCard.style.backgroundImage = "url('./Images/card.png')";
          firstCard.classList.remove("flipped");
          secondCard.classList.remove("flipped");
          firstCard = null;
          secondCard = null;
        }, 1000);
      }
    }
  }
  
  // Restart the game
  function restartGame() {
    gameCards = [...cards, ...cards].sort(() => Math.random() - 0.5);
    gameBoard.innerHTML = "";
    message.classList.add("hidden");
    gameBoard.classList.remove("hidden");
    matchedPairs = 0;
    createCards();
  }
  
  // Initialize the game
  createCards();
  